﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using QA;

class Program {
    static void Main() {
        Evaluation evaluation = new Evaluation();
    }
}

