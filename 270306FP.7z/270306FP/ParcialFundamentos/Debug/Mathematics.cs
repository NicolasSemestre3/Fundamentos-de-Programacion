﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QA {
    class Mathematics {
        
        public int CommonNames(string[] _data1, string[] _data2, string[] _data3) {
            int total = 0;
            for (int h = 0; h < _data1.Length; h++) {
                for (int i = 0; i < _data2.Length; i++) {
                    for (int j = 0; j < _data3.Length; j++) {
                        if (_data3[j] == _data2[i] && _data3[j] == _data1[h]) total++;
                    }
                }
            }
            return total;
        }

        /// <summary> Returns and array that contains the closest n names to the value (sorted based on the data)
        /// if Flag = 1 return the last n names </summary>
        public string[] ClosestToValue(string[] _names, double[] _data, double _value, int _n, int _flag = 0) {
            double[] data = new double[_data.Length]; _data.CopyTo(data, 0);
            string[] names = new string[_names.Length]; _names.CopyTo(names, 0);
            double[] distances = Deviations(data, _value);
            Sort(ref distances, ref names, _flag);
            string[] output = new string[_n];
            for (int i = 0; i < _n; i++) {
                output[i] = names[i];
            }
            return output;
        }

        /// <summary> Returns and array that contains the first n names (sorted based on the data)
        /// if Flag = 1 return the last n names </summary>
        public string[] TopNames(string[] _names, double[] _data, int _n, int _flag = 0) {
            double[] data = new double[_data.Length]; _data.CopyTo(data, 0);
            string[] names = new string[_names.Length]; _names.CopyTo(names, 0);
            Sort(ref data, ref names, _flag);
            string[] top = new string[_n];
            for (int i = 0; i < _n; i++) {
                top[i] = names[i];
            }
            return top;
        }

        /// <summary> Returns and array that contains the names which data is greater
        /// or equal (Flag = 0) to the threshold. Lower or equal if Flag = 1</summary>
        public string[] ThresholdNames(string[] _names, double[] _data, double _threshold, int _flag = 0) {
            double[] data = new double[_data.Length]; _data.CopyTo(data, 0);
            string[] names = new string[_names.Length]; _names.CopyTo(names, 0);
            Sort(ref data, ref names);

            int total = 0;
            for (int i = 0; i < data.Length; i++) {
                if ((data[i] >= _threshold && _flag==0) || (data[i] <= _threshold && _flag == 1)) {
                    total++;
                }
            }
            string[] top = new string[total];
            for (int i = 0; i < top.Length; i++) {
                if(_flag == 0) top[i] = names[i];
                else top[i] = names[names.Length-i-1];
            }
            return top;
        }

        /// <summary> Returns the number of times a letter is found </summary>
        public int CountLetter(string _word, char _letter) {
            int total = 0;
            for (int i = 0; i < _word.Length; i++) {
                if (_word[i] == _letter) {
                    total++;
                }
            }
            return total;
        }

        /// <summary> Returns the words that include letter </summary>
        public List<string> WordsWithLetter(string[] _words, char _letter) {
            List<string> result = new List<string>();
            for (int i = 0; i < _words.Length; i++) {
                if (CountLetter(_words[i],_letter) > 0) {
                    result.Add(_words[i]);
                }
            }
            return result;
        }

        /// <summary> Returns a list that contains the first position of the word found
        /// in the phrase. Returns -1 if the word is not found </summary>
        public List<int> FindWordPositions(string _word, string _phrase) {
            _word = _word.ToUpper();
            _phrase = _phrase.ToUpper();

            List<int> data = new List<int>();
            for (int i = 0; i < _phrase.Length- _word.Length + 1; i++) {
                string word = "";
                for (int j = 0; j < _word.Length; j++) {
                    word += _phrase[i + j];
                }

                if (word == _word) {
                    data.Add(i);
                }
            }
            if (data.Count == 0) data.Add(-1);
            return data;
        }

        /// <summary> Returns true if the word is in the index position </summary>
        public bool IsWordInPosition(string _word, string _phrase, int _index) {
            if (FindWordPositions(_word, _phrase)[0] == _index) return true;
            return false;
        }

        /// <summary> Returns true if any of the words is in the index position
        /// Words must be space separated strings</summary>
        public bool AreWordsInPosition(string _words, string _phrase, int _index) {
            string[] words = _words.Split(' ');
            for (int i = 0; i < words.Length; i++) {
                if (IsWordInPosition(words[i], _phrase, _index)) return true;
            }
            return false;
        }

        /// <summary> Returns Median</summary>
        public double Median(double[] _data) {
            double[] data = new double[_data.Length];
            _data.CopyTo(data, 0);
            Sort(ref data);
            int length = data.Length;
            if (length % 2 == 0) {
                double sum = data[(int)length / 2] + data[(int)(length - 1) / 2];
                return sum / 2;
            }
            return data[(int)(length - 1) / 2];
        }

        /// <summary> Returns distances to reference</summary>
        public double[] Deviations(double[] _data, double _reference) {
            double[] deviation = new double[_data.Length];
            for (int i = 0; i < _data.Length; i++) {
                deviation[i] = (_data[i] - _reference) * (_data[i] - _reference);
            }
            return deviation;
        }

        /// <summary> Returns distances to average</summary>
        public double[] Deviations(double[] _data) {
            double average = Average(_data);
            return Deviations(_data, average);
        }

        /// <summary> Returns standard deviation</summary>
        public double Deviation(double[] _data) {
            double[] deviations = Deviations(_data);
            return Math.Sqrt(Average(deviations));
        }

        /// <summary> Returns Average</summary>
        public double Average(double[] _data) {
            return ((double)_data.Sum()) / _data.Length;
        }

        /// <summary> Sort</summary>
        public static void Sort(ref double[] _data, int _flag = 0) {
            for (int i = 0; i < _data.Length; i++) {
                for (int j = 0; j < _data.Length - 1; j++) {
                    if ((_data[j] < _data[j + 1] && _flag == 0) || (_data[j] > _data[j + 1] && _flag == 1)) {
                        double tmp1 = _data[j];
                        _data[j] = _data[j + 1];
                        _data[j + 1] = tmp1;
                    }
                }
            }
        }

        /// <summary> Sort the arrays based on the data1 array.
        /// Flag: 0 - descendent | 1 - ascendent </summary>
        public static void Sort(ref double[] _data1, ref string[] _data2, int _flag=0) {
            for (int i = 0; i < _data1.Length; i++) {
                for (int j = 0; j < _data1.Length - 1; j++) {
                    if ((_data1[j] < _data1[j + 1] && _flag == 0) || (_data1[j] > _data1[j + 1] && _flag == 1)) {
                        double tmp1 = _data1[j];
                        _data1[j] = _data1[j + 1];
                        _data1[j + 1] = tmp1;
                        string tmp2 = _data2[j];
                        _data2[j] = _data2[j + 1];
                        _data2[j + 1] = tmp2;
                    }
                }
            }
        }

        
    }
}
