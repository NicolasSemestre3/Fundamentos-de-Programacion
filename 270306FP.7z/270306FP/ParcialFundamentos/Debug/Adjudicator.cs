﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using QA;

class Adjudicator {

    public double Compare(int _actual, int _expected) {
        Console.WriteLine("Esperado: " + _expected);
        Console.WriteLine("Recibido: " + _actual);
        if (_actual == _expected) return 1;
        return 0;
    }

    /// <summary> flag = 0: Order matter, flag = 1: Order doesn't matter </summary>
    public double Compare(string[] _actual, List<string> _expected, int _flag) {
        string[] expected = _expected.ToArray();
        return Compare(_actual, expected, _flag);
    }

    /// <summary> flag = 0: Order matter, flag = 1: Order doesn't matter </summary>
    public double Compare(string[] _actual, string[] _expected, int _flag) {

        if (_expected.Length == 0) {
            Console.WriteLine("Error. Los datos generados no permiten verificar el funcionamiento del punto");
            return 0;
        }

        if (_actual.Length != _expected.Length) {
            Console.WriteLine("Error. Las dimensiones del arreglo no son la correctas");
            Console.WriteLine("Salida esperada: ");
            for (int i = 0; i < _expected.Length; i++) Console.WriteLine(_expected[i]);
            return 0;
        }

        string[] actual = new string[_actual.Length];
        _actual.CopyTo(actual, 0);
        string[] expected = new string[_expected.Length];
        _expected.CopyTo(expected, 0);

        if (_flag == 1) {
            Array.Sort(actual);
            Array.Sort(expected);
        }
        
        double total = 0;
        Console.WriteLine("Comparando: ");
        for (int i = 0; i < actual.Length; i++) {
            Console.WriteLine(actual[i] + " vs " + expected[i]);
            if (actual[i] == expected[i]) {
                total+=1;
            }
        }
        if (total < actual.Length) {
            double percentage = Generator.DecimalReducton(total / actual.Length)*100;
            Console.WriteLine("Error. Coincidieron " + percentage + "% de los datos");
            return 0;
        }

        Console.WriteLine("Coinciden el 100% de los datos");
        return 1;
    }
}
