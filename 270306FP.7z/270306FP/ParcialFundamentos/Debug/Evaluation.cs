﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using QA;

class Evaluation {

    static Random random = new Random();
    Parcial parcial;
    Mathematics mathematics;
    Adjudicator adjudicator;

    Generator generator;
    double[] data;
    string[] names;

    public Evaluation() {
        adjudicator = new Adjudicator();
        generator = new Generator();
        mathematics = new Mathematics();

        int n = random.Next(6, 10);
        data = generator.Generate(n, 5);
        names = generator.GeneratePseudoWords(n);
        parcial = new Parcial(names, data);
        Console.WriteLine("\nDatos originales");
        for (int i = 0; i < data.Length; i++) {
            Console.WriteLine(names[i] + ": " + data[i]);
        }

        double total = 0;

        if (Parcial.codigo == 0) total = S001E1() + S001E2() + S001E3() + S001E4();
        if (Parcial.codigo == 1) total = S002E1() + S002E2() + S002E3() + S002E4();
        if (Parcial.codigo == 2) total = P001E1() + P001E2() + P001E3() + P001E4();


        Console.WriteLine("\nNota final: " + total);
    }



    
    double S001E1() { // Contar la cantidad de estudiantes con promedio inferior a 3.0
        Console.WriteLine("\nPrimer punto");
        string[] result = mathematics.ThresholdNames(names, data, 3.0,1);
        return 0.5 * adjudicator.Compare(parcial.PrimerPunto(), result.Length);
    }

    double S001E2() { // Encontrar los nombres de 5 estudiantes con promedio más bajo
        Console.WriteLine("\nSegundo punto");
        string[] result = mathematics.TopNames(names, data, 5, 1);
        return 1.5 * adjudicator.Compare(parcial.SegundoPunto(), result, 1);
    }

    double S001E3() { // Contar la cantidad de estudiantes con promedio inferior a 3.0
        Console.WriteLine("\nTercer punto");
        string[] result = mathematics.ThresholdNames(names, data, 3.0, 1);
        return 2.0 * adjudicator.Compare(parcial.TercerPunto(), result, 1);
    }

    double S001E4() { // Encontrar los nombres de los estudiantes con A en su nombre
        Console.WriteLine("\nCuarto punto");
        List<string> result = mathematics.WordsWithLetter(names,'A');
        return 2.0 * adjudicator.Compare(parcial.CuartoPunto(), result,0);
    }

    //--
    double S002E1() { // Contar la cantidad de estudiantes con nota inferior o igual al promedio de todos los estudiantes
        Console.WriteLine("\nPrimer punto");
        string[] result = mathematics.ThresholdNames(names, data, mathematics.Average(data), 1);
        return 0.5 * adjudicator.Compare(parcial.PrimerPunto(), result.Length);
    }

    double S002E2() { // Encontrar los nombres (5) de los estudiante con la nota más cercana al promedio
        Console.WriteLine("\nSegundo punto");
        string[] result = mathematics.ClosestToValue(names, data, mathematics.Average(data), 5, 1);
        return 1.5 * adjudicator.Compare(parcial.SegundoPunto(), result, 1);
    }

    double S002E3() { // Encontrar los nombres de las personas con nota igual o por encima del promedio
        Console.WriteLine("\nTercer punto");
        string[] result = mathematics.ThresholdNames(names, data, mathematics.Average(data), 0);
        return 2.0 * adjudicator.Compare(parcial.TercerPunto(), result, 1);
    }

    double S002E4() { // Encontrar los nombres de los estudiantes cuyo nombre inicia por vocal
        Console.WriteLine("\nCuarto punto");
        List<string> result = new List<string>();
        for (int i = 0; i < names.Length; i++) {
            if (mathematics.AreWordsInPosition("A E I O U", names[i], 0)) result.Add(names[i]);
        }
        return 2.0 * adjudicator.Compare(parcial.CuartoPunto(), result, 0);
    }

    //--
    double P001E1() { // Contar la cantidad de estudiantes con nota superior o igual a la suma del promedio y la desviación estándar de todos los estudiantes
        Console.WriteLine("\nPrimer punto");
        string[] result = mathematics.ThresholdNames(names, data, mathematics.Average(data) + mathematics.Deviation(data), 0);
        return 0.5 * adjudicator.Compare(parcial.PrimerPunto(), result.Length);
    }

    double P001E2() { // Encontrar los nombres (5) de los estudiantes con la desviación estándar más alta
        Console.WriteLine("\nSegundo punto");
        string[] result = mathematics.ClosestToValue(names, data, mathematics.Average(data), 5, 0);
        return 1.5 * adjudicator.Compare(parcial.SegundoPunto(), result, 1);
    }

    double P001E3() { // Encontrar los nombres de las personas con nota igual o por encima de la suma del promedio y la desviación estándar
        Console.WriteLine("\nTercer punto");
        string[] result = mathematics.ThresholdNames(names, data, mathematics.Average(data) + mathematics.Deviation(data), 0);
        return 2.0 * adjudicator.Compare(parcial.TercerPunto(), result, 1);
    }

    double P001E4() { // Encontrar los nombres de los estudiantes cuyo NO nombre inicia por vocal
        Console.WriteLine("\nCuarto punto");
        List<string> result = new List<string>();
        for (int i = 0; i < names.Length; i++) {
            if (!mathematics.AreWordsInPosition("A E I O U", names[i], 0)) result.Add(names[i]);
        }
        return 2.0 * adjudicator.Compare(parcial.CuartoPunto(), result, 0);
    }

    //--
    double LowerHalf() {
        Console.WriteLine("\nSegundo punto");
        string[] result1 = parcial.SegundoPunto();
        string[] result2 = mathematics.ThresholdNames(names, data, mathematics.Median(data),1);
        return 2*adjudicator.Compare(result1, result2, 1);
    }

    //2.0 puntos
    double CountBetterThanAverage() {
        Console.WriteLine("\nPrimer punto");
        int result1 = parcial.PrimerPunto();
        double threshold = Math.Min(data.Average() + 0.2, 3.8);
        string[] result2 = mathematics.ThresholdNames(names, data, threshold);
        Console.WriteLine("Recibido: " + result1);
        Console.WriteLine("Esperado: " + result2.Length);
        if (result1 == result2.Length) return 1.5;
        else return 0;
    }

    //2.0 puntos
    double AlreadyWon() {
        Console.WriteLine("\nSegundo punto");
        string[] result1 = parcial.SegundoPunto();
        string[] result2 = mathematics.ThresholdNames(names, data, data.Sum()/data.Length);
        return 2.0 * adjudicator.Compare(result1, result2, 1);
    }

    /*
     * 18-20
     total += CountBetterThanAverage();
        total += LowerHalf();
        total += DoWordStartWithVocal();
         */

    //1.5 puntos
    /*double TopNames() {
        string[] result1 = parcial.PrimerPunto();
        string[] result2 = mathematics.TopNames(names, data, 5, 1);
        return 1.5*adjudicator.Compare(result1, result2, 1);
    }*/

    /*double CountLetters() {
        Console.WriteLine("\nTercer punto");
        int total = 0;
        for (int i = 0; i < names.Length; i++) {
            if (mathematics.CountLetter(names[i], 'U') > 0) {
                total++;
            }
        }
        int recibido = parcial.TercerPunto();
        Console.WriteLine("Esperado: " + total + " | Recibido: " + recibido);
        if (total == recibido) { return 2.0; }
        return 0;

    }*/

    //2.0 puntos
    double CommonNames() {
        Console.WriteLine("\nTercer punto");
        string[] rawNames1 = generator.GeneratePseudoWords(random.Next(3, 12), 1);
        string[] rawNames2 = generator.GeneratePseudoWords(random.Next(3, 12), 1);
        string[] rawNames3 = generator.GeneratePseudoWords(random.Next(3, 12), 1);

        string[] names1 = rawNames1.Distinct().ToArray();
        string[] names2 = rawNames2.Distinct().ToArray();
        string[] names3 = rawNames3.Distinct().ToArray();

        Console.Write("Códigos 1: ");
        for (int i = 0; i < names1.Length; i++) {
            Console.Write(names1[i] + " | ");
        }
        Console.Write("\nCódigos 2: ");
        for (int i = 0; i < names2.Length; i++) {
            Console.Write(names2[i] + " | ");
        }
        Console.Write("\nCódigos 3: ");
        for (int i = 0; i < names3.Length; i++) {
            Console.Write(names3[i] + " | ");
        }
        Console.WriteLine();

        int repeated1 = mathematics.CommonNames(names1, names2, names3);
        int repeated2 = 0;//parcial.TercerPunto(names1, names2, names3);

        Console.WriteLine("Códigos repetidos (esperados): " + repeated1);
        Console.WriteLine("Códigos repetidos (obtenidos): " + repeated2);
        if (repeated1 == repeated2 && repeated1 == 0) {
            Console.WriteLine("No es concluyente. Debe ejecutar nuevamente.");
            return 0;
        }
        if (repeated1 == repeated2) return 2.0;

        return 0;
    }
}
