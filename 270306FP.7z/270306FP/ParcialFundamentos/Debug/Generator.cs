﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QA {
    class Generator {

        static Random random = new Random();
        string letters = "ABCDEGHIJLMNOPRSTUVY";
        string selected = "A";
        string vocals = "AEIOU";

        public double[] Generate(int _n, double _upper) {

            double[] data = new double[_n];
            for (int i = 0; i < data.Length; i++) {
                data[i] = DecimalReducton(random.NextDouble() * _upper);
            }
            return data;
        }


        public string[] GeneratePseudoWords(int _n, int _flag = 0) {
            string[] data = new string[_n];
            for (int i = 0; i < data.Length; i++) {
                data[i] = GeneratePseudoWord(_flag);
            }
            return data;
        }

        public string GeneratePseudoWord(int _flag = 0) {
            int n = 0;

            if (_flag == 0) n = random.Next(2, 5);
            else n = 2;
            string word = "";
            for (int i = 0; i < n; i++) {
                word += GenerateSyllabe(_flag);
            }
            return word;
        }

        string GenerateSyllabe(int _flag = 0) {

            int i = random.Next(0, vocals.Length);
            int j = 0;
            if (_flag == 0) {
                j = random.Next(0, letters.Length);
                return letters[j].ToString() + vocals[i].ToString();
            }
            j = random.Next(0, selected.Length);
            i = random.Next(0, 3);
            return selected[j].ToString() + vocals[i].ToString();
        }

        public static double DecimalReducton(double _value) {
            int value = (int)(_value * 100.0);
            return (double)(value) / 100.0;
        }
    }
}
